import React from 'react';

const AdminDashboard = () => {
  return (
    <div>
      <h1>Bienvenido, Admin!</h1>
      <p>Aquí puedes gestionar las funcionalidades de administración.</p>
    </div>
  );
};

export default AdminDashboard;
