import React from 'react';

const SellerDashboard = () => {
  return (
    <div>
      <h1>Bienvenido, Vendedor!</h1>
      <p>Aquí puedes gestionar tus ventas y clientes.</p>
    </div>
  );
};

export default SellerDashboard;
