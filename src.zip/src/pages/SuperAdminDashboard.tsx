import React from 'react';

const SuperAdminDashboard = () => {
  return (
    <div>
      <h1>Bienvenido, SuperAdmin!</h1>
      <p>Aquí puedes gestionar todas las funcionalidades del sistema.</p>
    </div>
  );
};

export default SuperAdminDashboard;
